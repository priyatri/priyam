package com.capgemini.salesmanagement.dao;

import java.util.HashMap;

import com.capgemini.salesmanagement.beans.Sale;

public class SaleDao implements ISaleDao
{
	 HashMap<Integer,Sale> hm= new HashMap<Integer,Sale>();
	

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) 
	{
		hm.put(sale.getSaleId(),sale);
		return hm;
	}

}
