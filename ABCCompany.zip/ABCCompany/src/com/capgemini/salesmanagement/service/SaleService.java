package com.capgemini.salesmanagement.service;

import java.util.HashMap;

import com.capgemini.salesmanagement.beans.Sale;
import com.capgemini.salesmanagement.dao.ISaleDao;
import com.capgemini.salesmanagement.dao.SaleDao;

public class SaleService implements ISaleService
{
	ISaleDao isale= new SaleDao();
	public SaleService()
	{
		super();
	}

	public SaleService(ISaleDao isale)
	{
		super();
		this.isale = isale;
	}
	 HashMap<Integer,Sale> hm= new HashMap<Integer,Sale>();

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale)
	{
		System.out.println("service: " + sale);
		hm=isale.insertSalesDetails(sale);
		System.out.println(hm);
		return hm;
	}

	@Override
	public boolean validateProductCode(int productId) 
	{
		if(productId==1001||productId==1002||productId==1003||productId==1004)
			return true;
		return false;
	}

	@Override
	public boolean validateQuantity(int qty)
	{
	if(qty>0&&qty<5)
		      return true;
		return false;
	}

	@Override
	public boolean validateProductCat(String prodCat)
	{
	if(prodCat.equals("ELECTRONICS")||prodCat.equals("TOYS"))
		return true;
		return false;
	}

	@Override
	public boolean validateProductName(String prodName, int flag) 
	{
		if((flag==0) && prodName.equals("SMART PHONE")|| prodName.equals("VIDEO GAME")|| prodName.equals("TV")|| prodName.equals("SOFT TOY")|| prodName.equals("TELESCOPE")|| prodName.equals("BARBEE DOLL"))
			return true;

		return false;
	}

	@Override
	public boolean validateProductPrice(float price)
	{
		if(price>200)
			return true;

		return false;
	}
}
