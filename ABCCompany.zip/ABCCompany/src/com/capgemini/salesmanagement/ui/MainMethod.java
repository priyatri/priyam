package com.capgemini.salesmanagement.ui;

import com.capgemini.salesmanagement.dao.ISaleDao;
import com.capgemini.salesmanagement.dao.SaleDao;
import com.capgemini.salesmanagement.service.ISaleService;
import com.capgemini.salesmanagement.service.SaleService;

public class MainMethod
{
	public static void main(String[] args)
	{
		ISaleDao dao= new SaleDao();
		ISaleService service= new SaleService(dao);
		
		
	}

}
