package com.capgemini.Exception;

public class ProductException extends Exception 
{

}
