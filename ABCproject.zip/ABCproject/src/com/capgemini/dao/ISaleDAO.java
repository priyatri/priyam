package com.capgemini.dao;


import java.util.HashMap;

import com.capgemini.beans.Sale;

public interface ISaleDAO 
{
public HashMap<Integer,Sale>insertSalesDetails(Sale sale);
}
