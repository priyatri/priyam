package com.capgemini.dao;

import java.util.HashMap;

import com.capgemini.beans.Sale;
import com.capgemini.util.CollectionUtil;

public class SaleDAO implements ISaleDAO
{
HashMap<Integer,Sale> hm;
	

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale)
	{
	hm= CollectionUtil.getCollection();
	hm.put(sale.getSaleId(), sale);
	return hm;
	}

}
