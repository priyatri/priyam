package com.capgemini.service;

import java.util.HashMap;

import com.capgemini.beans.Sale;
import com.capgemini.dao.SaleDAO;

public class SaleService implements ISaleService
{
	SaleDAO dao=new SaleDAO();
	HashMap<Integer,Sale> ref;

	@Override
	public HashMap<Integer, Sale> insertSalesDetails(Sale sale) {
	ref = dao.insertSalesDetails(sale);
		return ref;
	}

	@Override
	public boolean validateProductCode(int productId) {
	if((productId==1001)||(productId==1002)||(productId==1003)||(productId==1004))
		return true;
	else
		return false;
	}

	@Override
	public boolean validateQuantity1(int qty) {
if(qty>0&&qty<5)
	return true;
else
		return false;
	}

	@Override
	public boolean validateProductCat(String prodCat) {
		if((prodCat.equals("Electronics"))||(prodCat.equals("Toys")))
			return true;
		else
		return false;
	}

	@Override
	public boolean validateProductName(String prodName)
	{
	if((prodName.equals("TV"))||(prodName.equals("Smart Phone"))||(prodName.equals("Video game"))||(prodName.equals("soft toy"))||(prodName.equals("Telescope"))||(prodName.equals("Barbee doll")))
		return true;
	else
		return false;
	}

	@Override
	public boolean validateProductPrice(float price)
	{
		if(price>200)
			return true;
		else
		return false;
	}

}
