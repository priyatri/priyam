package com.capgemini.ui;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.Exception.ProductException;
import com.capgemini.service.SaleService;
import com.capgemini.beans.*;
public class Entry
{
	public static void main(String[]args) throws ProductException
	{
		HashMap<Integer,Sale> hm;

		SaleService ser=new SaleService();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter product code");
		int a=sc.nextInt();
		if(ser.validateProductCode(a)==false)
		{
			System.out.println("the Id must be 1001 to 1004");
			System.exit(0);
		}
System.out.println("enter the quantity");
int b=sc.nextInt();
if(ser.validateQuantity1(b)==false)
{
	System.out.println("qty error");
	System.exit(0);
}
System.out.println("enter product category");
String c=sc.next();
if(ser.validateProductCat(c)==false)
{
	System.out.println("ctg erropr");
	System.exit(0);
}
System.out.println("enter product name");
sc.nextLine();
String d= sc.nextLine();
if(ser.validateProductName(d)==false)
{
	System.out.println("hjhjyhjy4");
	System.exit(0);
}
System.out.println("enter product description");
String e=sc.next();
System.out.println("enter price");
float p=sc.nextFloat();
if(ser.validateProductPrice(p)==false)
{
	System.out.println("tgncfnh");
	System.exit(0);
}
LocalDate dt= LocalDate.now();
float linetotal;
linetotal=p*b;
Sale sa=new Sale(a,d,c,dt,b,linetotal);

System.out.println("enter 1 to calculate bill and display line total");
System.out.println("enter 2 to exit");
System.out.println("enter choice");
int choice=sc.nextInt();
switch(choice)
{
case 1:  
{
	int qty;
	System.out.println("Quantity: "+b);
	linetotal=p*b;
	System.out.println("LineTotal:"+linetotal);
	
	
	
	hm=ser.insertSalesDetails(sa);
	for(Map.Entry<Integer, Sale> i: hm.entrySet())
	{
		System.out.println(i.getKey());
		System.out.println(i.getValue().getProductName());
	System.out.println(i.getValue().getCategory());
		System.out.println(i.getValue().getProdCode());
		System.out.println(i.getValue().getQuantity());
	}
	break;
	
}
case 2:
{
	System.exit(0);
	break;
}
default: System.out.println("wrong choice");

}}}