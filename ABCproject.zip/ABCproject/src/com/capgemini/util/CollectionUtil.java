package com.capgemini.util;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.beans.Sale;

public class CollectionUtil {
	private static HashMap<Integer, Sale> sales= new HashMap<Integer,Sale>();
	public static HashMap<Integer,Sale>getCollection()
	{
		return sales;
	}

}
