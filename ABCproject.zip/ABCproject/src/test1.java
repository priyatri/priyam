import static org.junit.Assert.*;

import org.junit.Test;

public class test1 {

	@Test
	public void test() {
	
	}

}
