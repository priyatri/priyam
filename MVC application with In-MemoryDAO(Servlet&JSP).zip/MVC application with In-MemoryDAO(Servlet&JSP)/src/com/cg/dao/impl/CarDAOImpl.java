package com.cg.dao.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.dao.CarDAO;
import com.cg.dto.CarDTO;

public class CarDAOImpl implements CarDAO 
{
Map<Integer, CarDTO> rev= new HashMap<Integer, CarDTO>();

	@Override
	public List<CarDTO> findAll() 
	{
 List<CarDTO> list= new ArrayList<>(rev.values());
 return list;
	}

	@Override
	public CarDTO findById(int id)
	{
		return rev.get(id);
	}

	@Override
	public void create(CarDTO car)
	{
		CarDTO cardtoref;
		cardtoref=rev.put(car.getId(), car);
		System.out.println("Created");
	
    
	}
	@Override
	public void update(CarDTO car)
	{
		CarDTO c=  rev.put(car.getId(), car);
		System.out.println("Updated");
		
	}
	@Override
	public void delete(String[] ids)
	{
	for(String i: ids)
	{
		rev.remove(Integer.parseInt(i));
	}

	}

}
