package com.capgemini.repo;

import java.util.HashMap;

import com.capgemini.beans.Trainer;

public interface FeedbackDao 
{
public void addFeedback(Trainer trainer);
public HashMap<Integer,Trainer> getTrainerList();
}
