import java.util.Map;
import java.util.Scanner;

import com.capgemini.beans.Trainer;
import com.capgemini.service.FeedbackServiceImpl;

public class main
{
public static void main(String[] args)
{
	FeedbackServiceImpl ser= new FeedbackServiceImpl();
	Scanner sc=new Scanner(System.in);
		System.out.println("enter trainer name");	
	String s=sc.next();
	System.out.println("enter course name");	
	String d=sc.next();
	System.out.println("enter start date(dd-MM-yyyy)");	
	String sd=sc.next();
	System.out.println("enter end date(dd-MM-yyyy)");	
	String ed=sc.next();
	System.out.println("enter feedback rating");	
	int a=sc.nextInt();
	

	Trainer tre= new Trainer(s,d,sd,ed,a);
	
	ser.addFeedback(tre);
	Map<Integer,Trainer> map=ser.getTrainerList();
	for(Map.Entry<Integer, Trainer> i: map.entrySet())
	{
		
	System.out.println(i.getValue().getName());
	System.out.println(i.getValue().getCoursename());
	System.out.println(i.getValue().getStartDate());
	System.out.println(i.getValue().getEnddate());
	System.out.println(i.getValue().getRating());
	}
	
	
	



}
	
}
