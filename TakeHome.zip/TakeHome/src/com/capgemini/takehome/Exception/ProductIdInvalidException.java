package com.capgemini.takehome.Exception;

public class ProductIdInvalidException extends Exception
{
}
