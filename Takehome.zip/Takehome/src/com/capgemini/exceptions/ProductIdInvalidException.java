package com.capgemini.exceptions;

public class ProductIdInvalidException extends Exception {

}
