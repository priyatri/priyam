package com.capgemini.Dao;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.beans.Customer;
import com.capgemini.util.Utility;

public class WalletRepoImpl implements WalletRepo
{
Map<String,Customer> map=Utility.getMap();
	@Override
	public boolean Save(Customer c)
	{
map.put(c.getPhonenumber(), c);
		return true;
	}

	@Override
	public Customer findByPhoneNumber(String phonenumber) {
		// TODO Auto-generated method stub
	Customer s=	map.get(phonenumber);
		return s;
	}

}
