package com.capgemini.Entry;

import java.math.BigDecimal;

import com.capgemini.Dao.WalletRepoImpl;
import com.capgemini.Exception.PhoneNumberDoesNotExistException;
import com.capgemini.Service.WalletService;
import com.capgemini.Service.WalletServiceImpl;
import com.capgemini.beans.Customer;

public class Entry1
{
	public static void main(String[]args)throws PhoneNumberDoesNotExistException
	{
		WalletService walletservice= new WalletServiceImpl();
		Customer c1=walletservice.createAccount("priyam", "1", new BigDecimal("3000"));
		Customer c2=walletservice.createAccount("priya", "2", new BigDecimal("4000"));
		System.out.println();
		System.out.println();

		c1=walletservice.Withdraw("1", new BigDecimal("1000"));
		
	System.out.println(c1.getWallet().getBalance());
	System.out.println(walletservice.Withdraw("2", new BigDecimal("2000")));
	
	
	System.out.println(walletservice.Deposit("1", new BigDecimal("1000")));
	System.out.println(walletservice.Deposit("2", new BigDecimal("2000")));
	c2=walletservice.fundTransfer("1", "2",new BigDecimal("2000"));
	System.out.println(c2.getWallet().getBalance());
	
	
		}
}
	
	
	
	
	
	
	
