package com.capgemini.Exception;

public class PhoneNumberDoesNotExistException extends Exception {

}
