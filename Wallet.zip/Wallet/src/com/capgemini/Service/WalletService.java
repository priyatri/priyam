package com.capgemini.Service;

import java.math.BigDecimal;

import com.capgemini.beans.Customer;

public interface WalletService
{
Customer createAccount(String name, String phonenumber,BigDecimal amount);
Customer showBalance(String phonenumber);
Customer Deposit(String phonenumber,BigDecimal amount);
Customer Withdraw(String phonenumber,BigDecimal amount);
Customer fundTransfer(String targetphonenumber,String sourcephonenumber, BigDecimal amount);
}
