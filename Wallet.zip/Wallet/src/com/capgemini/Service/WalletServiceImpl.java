package com.capgemini.Service;

import java.math.BigDecimal;

import com.capgemini.Dao.WalletRepo;
import com.capgemini.Dao.WalletRepoImpl;
import com.capgemini.beans.Customer;
import com.capgemini.beans.Wallet;

public class WalletServiceImpl implements WalletService 
{

	WalletRepo res= new WalletRepoImpl();

	@Override
	public Customer createAccount(String name, String phonenumber, BigDecimal amount)
	{
		
		Wallet wallet=new Wallet(1, amount);
		Customer d=new Customer( name,  phonenumber, wallet );
	     res.Save(d);
		return d;
	}

	@Override
	public Customer showBalance(String phonenumber)
	{
		Customer c=res.findByPhoneNumber(phonenumber);
		return c;
	}

	@Override
	public Customer Deposit(String phonenumber, BigDecimal amount)
	{
		 Customer t=res.findByPhoneNumber(phonenumber);
		 t.getWallet().setBalance(t.getWallet().getBalance().add(amount));

		 return t;
	
	}

	@Override
	public Customer Withdraw(String phonenumber, BigDecimal amount)
	{
     Customer a=res.findByPhoneNumber(phonenumber);
     a.getWallet().setBalance(a.getWallet().getBalance().subtract(amount));
		return a;
	}

	@Override
	public Customer fundTransfer(String targetphonenumber, String sourcephonenumber, BigDecimal amount)
	{
		Customer w=res.findByPhoneNumber(sourcephonenumber);
		Customer u=res.findByPhoneNumber(targetphonenumber);
		
		 u.getWallet().setBalance(u.getWallet().getBalance().add(amount));
		 w.getWallet().setBalance(w.getWallet().getBalance().subtract(amount));
		 return u;
	}
	  
}
