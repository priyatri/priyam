package com.capgemini.util;

import java.util.HashMap;
import java.util.Map;

import com.capgemini.beans.Customer;

public class Utility
{
	 static Map<String, Customer> map= new HashMap<String,Customer>();
	 public static  Map<String, Customer> getMap()
	 {
		 return map;
	 }

}
