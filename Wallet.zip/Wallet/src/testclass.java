import static org.junit.Assert.*;

import org.junit.Test;

public class testclass {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
